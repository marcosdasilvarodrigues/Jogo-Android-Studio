Jogo da forca - Desenvolvido em Java para Android

Jogo com funcionalidades basicas, troca de imagem e contagem de erros e acertos. Tema relacionado.


JOGO DA FORCA
O "Jogo da Forca" é um aplicativo Android que permite que os usuários joguem o clássico jogo de adivinhação.
O aplicativo oferece diversas categorias de palavras, como comidas, cidades, cores, cozinha, natureza,  e frutas, para que os usuários possam selecionar um tema e começar a jogar imediatamente. Além disso, os usuários também têm a opção de criar um jogo personalizado, digitando a palavra e a dica da forca.

Descrição Técnica
Este aplicativo foi desenvolvido em Kotlin utilizando o Android Studio. As palavras e dicas da forca são pré-salvas em um arquivo Json que pode ser encontrado aqui.
